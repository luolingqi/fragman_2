/**
 * @defgroup main Getting Started
 * @defgroup mainclasses Classes Overview 
 * @defgroup stereo Stereochemistry
 * @defgroup conformer Conformer Searching
 * @defgroup substructure Substructure Searching
 */
