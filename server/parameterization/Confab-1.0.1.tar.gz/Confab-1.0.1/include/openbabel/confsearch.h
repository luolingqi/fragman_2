#ifndef OB_CONFSEARCH_H
#define OB_CONFSEARCH_H

#include <openbabel/tree/tree.hh>
#include <openbabel/math/align.h>

#endif // OB_CONFSEARCH_H