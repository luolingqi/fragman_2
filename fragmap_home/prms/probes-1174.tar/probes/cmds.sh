< probes xargs -i ln -s ../rec/1rec.pdb {}/1rec.pdb
< probes xargs -i ln -s {}.ms {}/1lig.ms
